require("dotenv").config();
const path = require('path');
const fs = require('fs');
const chalk = require('chalk');
const moment = require('moment-timezone');
moment.tz.setDefault("Asia/Jakarta").locale("id")

const sekarang = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')

module.exports = {
	options: {
      public: false,
      antiCall: true, // reject call
      database: "database.json", // End .json when using JSON database or use Mongo URI
      owner: ["6288213503541", "6283850148706"], // set owner number on here
      pairing: "6288213503541",
      sessionName: "session", // for name session
      prefix: /^[°•π÷×¶∆£¢€¥®™+✓_|/~!?@#%^&.©^]/i,
      pairingNumber: "", // Example Input : 62xxx
      pathPlugins: "plugins",
      wm: ""
   },
   
   // Function Maybee
   reloadFile: (path) => reloadFile(path),
   
   // Rest APIs Cuy
   APIs: {
   	alya: "https://api.alyachan.pro"
   },
   
   APIKeys: {
   	"https://api.alyachan.pro": "rokumo"
   },
   
   // Set pack name sticker on here
   Exif: {
      packId: "Ryn",
      packName: null,
      packPublish: '         Ryn. - Assistant\n      ——————————————\n\nCreated on date:\n' + sekarang,
      packEmail: "roku-team@valnitio.com",
      packWebsite: "",
      androidApp: "",
      iOSApp: "",
      emojis: [],
      isAvatar: 1,
   },

   // message  response awikwok there
   msg: {
      owner: "Features can only be accessed owner!",
      group: "Features only accessible in group!",
      private: "Features only accessible private chat!",
      admin: "Features can only be accessed by group admin!",
      botAdmin: "Bot is not admin, can't use the features!",
      bot: "Features only accessible by me",
      media: "Reply media...",
      query: "Enter Query!",
      noUrl: "please input a url.",
      error: "An error occurred while retrieving data.",
      quoted: "Reply message...",
      wait: "Wait a minute...",
      urlInvalid: "Url Invalid",
      notFound: "Result Not Found!",
      premium: "Premium Only Features!"
   }
}

function reloadFile(file) {
  fs.watchFile(file, () => {
    fs.unwatchFile(file);
    console.log(chalk.green(`[ UPDATE ] file => "${file}"`));
    delete require.cache[require.resolve(file)];
    require(file);
  });
} 

reloadFile(require.resolve(__filename))
